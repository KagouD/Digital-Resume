#! /usr/local/bin/python3
import socket,sys,signal,socket,select,atexit,random,time,json,os

def escaped_latin1_to_utf8(s):
 res = '' ; i = 0
 while i < len(s):
     if s[i] == '%':
         res += chr(int(s[i+1:i+3], base=16))
         i += 3
     else :
         res += s[i]
         i += 1
 return res


def answer():
    message = """HTTP/1.1 200
    Content-Type: text/html; charset=utf-8
    Connection: close
    Content-Length: 125

    <!DOCTYPE html>
        <head>
            <title>Mon Projet Systeme</title>
        </head>
        <body>
        

        </body>
    </html>
    """
    mama=os.read(1,1000)
    os.write(1,message.encode("utf-8")) 
    os.write(1,mama)
if __name__ == '__main__':
    answer()
    sys.exit(0)
