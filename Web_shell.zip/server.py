#! /usr/local/bin/python3
import socket,sys,signal,socket,select,atexit,random,time,json,os
global server
global HOST
filspid=[]
HOST = "127.0.0.1"
PORT = 8080
MAXBYTES = 100000

#os.kill envoie un signal arg (pid du receveur,signal) 
def handler(signum,ignore):
    os.kill
    print("-----PROCESSUS INTERROMPU-----")

signal.signal(signal.SIGINT, handler) 
    
    
def init(HOST,PORT):
    
    global server
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, int(PORT)))  
    server.listen()
    f=os.getpid()
    print(f)
    print ("Le Serveur écoute sur le port:",PORT,",Adresse IP:",HOST)

global server,PC

def accept():
    global filspid
    nbfils=1
    global HOST
    global server
    if HOST == 0 :
        print("Connexion refusée, adresse IP non locale")
    else:
        while True: #boucle du server
            if(nbfils<=4): # si on peut accepter une connexion
                
                clientsocket,(addr,port) = server.accept() #on accepte
                
                #print("Nombre de clients connectés ->", nbfils)
                #arret()
                pid=os.fork()
                print("Connection acceptée ( pid =",os.getpid(),')\n')
                if pid==0: #fils
                    server.close() #le fils n'a plus besoin de la socket du server.
                    #print("Vous êtes connecté")
                    #print("Nombre de clients connectés ->", nbfils)
                    
                    #clientsocket.send(commande)
        
                    os.dup2(clientsocket.fileno(),1) #ici on "branche" le descripteur de fichier
                    #de la socket associé à la connexion à la sortie standard.
                    os.dup2(clientsocket.fileno(),0) #idem mais pour l'entrée standard
                                    
                    traitant = "traitant5.py"
                    os.execv(traitant, [traitant]) #modifier en execv car votre traitant n'est connu du $PATH pour utiliser execvp
                    
                    
                else: #pere
                    clientsocket.close() #si je suis le pere (le server en fait) je ferme la connexion avec le client, car c'est mon fils qui va l'utiliser.
                    nbfils=nbfils+1 #j'incremente mon nb de fils.
                    filspid.append(pid)
                    ## c'est ici qu'il faudra peut-etre ajouter à la liste_pid des fils, le pid du fils qui vient d'etre fork()
            else: #si il y a plus de 4 connexion alors j'attends la fin d'une connexion, c-a-d., attendre la mort d'un de mes fils.
                os.wait()
                nbfils=nbfils-1
                #server.close()

def handler(signum,ignore):
    global filspid
    for i in filspid:
        try:
            os.kill(i,signal.SIGINT)
        except:
            print('-----PROCESSUS INTERROMPU-----')
        os.wait()
    print("-----PROCESSUS INTERROMPU-----")
    sys.exit(0)
    

    
def mainloop():
    accept()
    
    
if __name__ == '__main__':
    signal.signal(signal.SIGINT, handler)
    HOST,PORT= "127.0.0.1",8080
    init(HOST,PORT)
    mainloop()
    
    
