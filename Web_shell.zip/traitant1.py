#!/usr/bin/env python3

import os, sys, time, signal

def test(chaine):
    if(chaine[0:14]!="GET / HTTP/1.1"):
        print("request not supported") 

if __name__ == '__main__' :
    #si dessous traitant 1
    commande = os.read(0,1000)
    commande = commande.decode("utf8")
    test(commande)
