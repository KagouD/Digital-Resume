#! /usr/local/bin/python3
import socket,sys,signal,socket,select,atexit,random,time,json,os


def escaped_latin1_to_utf8(s):
 res = '' ; i = 0
 while i < len(s):
     if s[i] == '%':
         res += chr(int(s[i+1:i+3], base=16))
         i += 3
     else :
         res += s[i]
         i += 1
 return res

PC=1000
PD=os.getppid()
def answer():
    message ="""HTTP/1.1 200
    Content-Type: text/html; charset=utf-8
    Connection: close
    Content-Length: 125

    <!DOCTYPE html>
        <head>
            <title>Mon Projet Systeme</title>
        </head>
        <body>
            <br/>
            <form action="bouton_{}" method="get">
            <p id="date" style="color:red"></p>
            <script>document.getElementById("date").innerHTML = Date();</script>
        <input type="text" name="saisie" value="" />
        <input type="submit" name="send" value="&#9166;">
    </form>
        </body>
    </html>
    """.format(PC)
    if PC=='': 
        fd = os.open("historique{}.txt".format(PC), os.O_RDWR|os.O_CREAT|os.O_APPEND)
        os.write(1,message.encode("utf-8"))  
        m=os.read(1,10000)
        ######-----EXTRACTION CHAINE--------##########
        v=str(m)
        q=int(v.index('&')-2)
        f=m[24:q] ###salut+je+m%27appelle+kkk
        s=str(f)
        q=escaped_latin1_to_utf8(s.replace('+', ' '))#b'salut je m'appelle kkk'
        x=q[2:-1]+' \n'
        os.write(fd,x.encode("utf-8"))
        os.close(fd)
        fd2 = os.open("historique{}.txt".format(PC), os.O_RDWR|os.O_CREAT|os.O_APPEND)
        r=os.read(fd2,10000).decode("utf8")
        #os.write(2,r.encode("utf-8"))
        r = r.replace(' \n',"<br>")
        os.write(1,r.encode("utf-8"))
        os.close(fd)
    else:
        fd = os.open("historique{}.txt".format(PD), os.O_RDWR|os.O_CREAT|os.O_APPEND)
        os.write(1,message.encode("utf-8")) 
        m=os.read(1,10000) #toute la requette
        v=str(m)
        q=int(v.index('&')-2)
        f=m[24:q] ###salut+je+m%27appelle+kkk
        s=str(f)
        q=escaped_latin1_to_utf8(s.replace('+', ' '))#b'salut je m'appelle kkk'
        x=q[2:-1]+' \n'
        os.write(fd,x.encode("utf-8"))
        os.close(fd)
        fd2 = os.open("historique{}.txt".format(PD), os.O_RDWR|os.O_CREAT|os.O_APPEND)
        r=os.read(fd2,10000).decode("utf8")
        #os.write(2,r.encode("utf-8"))
        r = r.replace(' \n',"<br>")
        os.write(1,r.encode("utf-8"))
        os.close(fd)
        
        
    


if __name__ == '__main__':
    #if la requete du client est une requête valide (ceci est à faire dans le traitant1, ici c'est plus un traitant2.py sans cette verification.
    #alors je lui reponds : answer()
    answer()
    sys.exit(0)
    #arret()
