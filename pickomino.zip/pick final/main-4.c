#include <stdio.h>
#include<stdlib.h>
#include<conio.h>
#include "jeu.h"
#include <time.h>
#include "jeu.c"




int main(void){

    FILE *fp;
    fp = fopen("file.txt","a");




    printf("\t\t=============================================\n");
    printf("\t\t|   ____                          ____      |\n");
    printf("\t\t|  | 21 |                        | 36 |     |\n");
    printf("\t\t|  |----|                        |----|     |\n");
    printf("\t\t|  | |  |       PICKOMINO        ||||||     |\n");
    printf("\t\t|   ----                          ----      |\n");
    printf("\t\t|    DI PLACIDO Anna          DIA Kagou     |\n");
    printf("\t\t|                                           |\n");
    printf("\t\t|                                           |\n");
    printf("\t\t=============================================\n");

    printf("\n\n--------------------------------------------------------------------------------------------------------------------\n\n");
    fprintf(fp,"\n\n--------------------------------------------------------------------------------------------------------------------\n");
    fprintf(fp,"\n  NOUVELLE PARTIE\n\n");

    fprintf(fp,"\t\t=============================================\n");
    fprintf(fp,"\t\t|   ____                          ____      |\n");
    fprintf(fp,"\t\t|  | 21 |                        | 36 |     |\n");
    fprintf(fp,"\t\t|  |----|                        |----|     |\n");
    fprintf(fp,"\t\t|  | |  |       PICKOMINO        ||||||     |\n");
    fprintf(fp,"\t\t|   ----                          ----      |\n");
    fprintf(fp,"\t\t|    DI PLACIDO Anna          DIA Kagou     |\n");
    fprintf(fp,"\t\t|                                           |\n");
    fprintf(fp,"\t\t=============================================\n");

    fprintf(fp,"\n\n--------------------------------------------------------------------------------------------------------------------\n\n");
    fprintf(fp,"\nCELUI QUI A LE PLUS GRAND SCORE FINAL EST LE DINDON GAGNANT\nFELICITATION !!! :D ");




    fclose(fp);


    piko();
    debutJeu();


    return 0;
}

