#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include<conio.h>
#include "jeu.h"
#include <sys/stat.h>


//------------------------------------------------------------------------------------------
void tab1ettab2(int *numpiko)
{
    ajout_pikomino(*numpiko);
    afficherpiletab();



}
//--------------------------------------------------------------------------------

void ajout_pikomino(int item) {
  if (p.top >= 16 - 1)
    return;
  p.top++;
  p.tab[p.top] = item;
}
int enlevedernierpiko() {
  if (p.top == -1)
    return 1;
   int item;
   item = p.tab[p.top];
   p.top--;
   return item;
}
void afficherpiletab() {
   int i;
   int j;
   if (p.top == -1){
      printf("\nLa pile est vide!");

   // else if (sizeof(p.tab))
   }
   else {
      for (i = p.top; i >= 0; i--)
         printf("\n%d", p.tab[i]);
        int a=16;
        if(p.tab[16]==0){

            printf("jeu termine");
            finjeu();
        }
    }

}

//----------------------------------------------------------------------------------------
/*
void afficherpiletab() {
   int i;
   int j;
   int a=0;
   if (p.top == -1){
      printf("\nLa pile est vide!");

   // else if (sizeof(p.tab))
   }
   else {
      for(i=0;i<sizeof(p.tab)/sizeof(*(p.tab));i++)
        {
            if(p.tab[j]!=0)

                a=a+1;

        }
        printf("a: %d",a);
            printf("jeu termine");
           // finjeu();
   }
}
*/


//-------------------------
/*int a=0;

        for(j=0;j<sizeof(tab)/sizeof(*tab);j++)
        {
            if(tab[j]!=0)

                a=a+1;

        }
        printf("a: %d",a);*/
//------------------------------------------------------------------------------------------------
//pile pour joueurs
/* *********************************************************************************** */
#define size 20

//----------------------------------------------------------------------------------
int milieuTable(int *numpiko)
{
      int j, i, n, key, l;
      int a[100]={21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36};


  //  printf("\nEnter the element to delete:");
    //scanf("%d", &key);
    l = 16;  //Length of the array
    for (i = 0; i < l; i++) {
        if (a[i] == *numpiko) {
           for (j = i; j < l; j++)
               a[j] = a[j + 1];
           l--;    //Decreasing the length of the array
        }
    }

    printf("\n\tLes pickominos restant sont : \n");
    for (i = 0; i < l; i++)
        printf(" [%d] ", a[i]);
    // getch();
}
//-------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
//stocke dans un tableau sous forme de pile les pickominos choisis par le joueur 1
// puis calcul le nombre de points totale pour ce joueur

int stockpickominojoueur1(int *numpiko)
{
    static int score1=0;
    int i;
    FILE *fp;
    fp = fopen("file.txt","a");
   ajout_pikomino1(*numpiko);
   //afficherpiletab1();
   //fprintf(fp,"pickominos choisis par joueur 1 : \n %d\n\n",afficherpiletab1);


   for(i=0;i<20;i++)
        if(p1.tab[i]== 21 || p1.tab[i]==22 || p1.tab[i]==23 || p1.tab[i]==24){
            score1 = score1 + 1;
        }
        else if(p1.tab[i]==25 || p1.tab[i]==26 || p1.tab[i]==27 || p1.tab[i]==28){
            score1 = score1 + 2;
        }
        else if(p1.tab[i]==29 || p1.tab[i]==30 || p1.tab[i]==31 || p1.tab[i]==32){
            score1 = score1 + 3;
        }
        else if(p1.tab[i]==33 || p1.tab[i]==34 || p1.tab[i]==35 || p1.tab[i]==36){
            score1 = score1 + 4;
        }
        printf("\nscore joueur 1 : %d\n",score1);
        fprintf(fp,"\nscore final joueur 1 = %d\n",score1);
        fclose(fp);

    return score1;
}
//--------------------------------------------------------------------------------------------------
//stocke dans un tableau sous forme de pile les pickominos choisis par le joueur 2
// puis calcul le nombre de points totale pour ce joueur
int stockpickominojoueur2(int *numpiko)
{
   ajout_pikomino2(*numpiko);
   //afficherpiletab2();
    static int score2=0;
   int i;
    FILE *fp;
   fp = fopen("file.txt","a");

   for(i=0;i<20;i++)
        if(p2.tab[i]== 21 || p2.tab[i]==22 || p2.tab[i]==23 || p2.tab[i]==24){
            score2 = score2 + 1;
        }
        else if(p2.tab[i]==25 || p2.tab[i]==26 || p2.tab[i]==27 || p2.tab[i]==28){
            score2 = score2 + 2;
        }
        else if(p2.tab[i]==29 || p2.tab[i]==30 || p2.tab[i]==31 || p2.tab[i]==32){
            score2 = score2 + 3;
        }
        else if(p2.tab[i]==33 || p2.tab[i]==34 || p2.tab[i]==35 || p2.tab[i]==36){
            score2 = score2 + 4;
        }
        printf("\nscore joueur 2 : %d\n",score2);
        fprintf(fp,"\nscore final joueur 2 = %d\n",score2);
        fclose(fp);


    return score2;
}

//-----------------------------------------------------------
//joueur 1 (fonctions pour sa pile de joueur1, pour ses pickominos)
// ajoute, supprime ou affiche pickominos

void ajout_pikomino1(int item) {
  if (p1.top >= size - 1)
    return;
  p1.top++;
  p1.tab[p1.top] = item;
}
int enlevedernierpiko1() {
  if (p1.top == -1)
    return 1;
   int item;
   item = p1.tab[p1.top];
   p1.top--;
   return item;
}
void afficherpiletab1() {
   int i;
   if (p1.top == -1)
      printf("\nLa pile est vide!");
   else {
      for (i = p1.top; i >= 0; i--)
         printf("\n%d", p1.tab[i]);
   }
}
//--------------------------------------------------------------------------------------------
//joueur 1 (fonctions pour sa pile de joueur 2, pour ses pickominos)
// ajoute, supprime ou affiche pickominos


void ajout_pikomino2(int item) {
  if (p2.top >= size - 1)
    return;
  p2.top++;
  p2.tab[p2.top] = item;
}
int enlevedernierpiko2() {
  if (p2.top == -1)
    return 1;
   int item;
   item = p2.tab[p2.top];
   p2.top--;
   return item;
}
void afficherpiletab2() {
   int i;
   if (p2.top == -1)
      printf("\nLa pile est vide!");
   else {
      for (i = p2.top; i >= 0; i--)
         printf("\n%d", p2.tab[i]);
   }
}


//-----------------------------------------------------------------------------------------------
//affiche les pikominos en debut de jeu +stocke les valeurs dans des variables
//a voire comment rendre ca moins complexe !
void piko()
{
    int j=0;
    printf("\t\tVoici les pikominos en debut de jeu : \n\n");
    int tab[17]={21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36};
    for (j=0;j<16;j++)
        printf("[%d]",tab[j]);


}
//--------------------------------------------------------------------------------------------------
void affichage(Liste* L){
    Liste* temp=L;
    while(temp!=NULL){
        printf("[%d]",temp->valeur);
        temp=temp->suivant;
    }
    printf("\n");
}
//----------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------
Liste* creerMaillon(int x){
    Liste* m = (Liste*)malloc(sizeof(Liste));
    m->valeur=x;
    m->suivant=NULL;
    return m;
}
//---------------------------------------------------------------------------------------------------------
Liste* insererEnTete(Liste* L,int x){
    Liste* m=creerMaillon(x);
    m->suivant=L;
    return m;
}
//-------------------------------------------------------------------------------------------------------------------------
Liste* insererEnFin(Liste* head,int x){
    Liste* m = creerMaillon(x);
    if(head==NULL){
        m->suivant=head;
        return m;
    }
    else{
        Liste* temp=head;
        while(temp->suivant!=NULL){
            temp=temp->suivant;
        }
        temp->suivant=m;
        return head;
    }
}
//---------------------------------------------------------------------------------------------------------------
Liste* supprimerUnElement(Liste* head,int x)
{
    if(head == NULL) return NULL;
    if(head->valeur==x){
        Liste* temp=head;
        head=head->suivant;
        free(temp);
    }
    else{
        Liste* temp1=head;
        Liste* temp2=NULL;
        while(temp1!=NULL && temp1->valeur!=x){
            temp2=temp1;
            temp1=temp1->suivant;
        }
        if(temp1==NULL)
            printf("La valeur recherchee n existe pas dans la liste\n");
        else{
            temp2->suivant=temp1->suivant;
            free(temp1);
        }
    }
    return head;
}
//----------------------------------------------------------------------------------------------------------

struct tableau{
    int tab[100];
    int nbelem;
}tableau;
//-----------------------------------------------------------------------------------------
//compte le nb d'occurence d'un nombre dans un tableau

int nombreOccurence(int tab[],int x ,int nbr){
    int i;
    int compteur = 0;
    for(i=0;i<x;i++){
        if(tab[i]==nbr)
            compteur++;
    }
    printf("nb : %d\n",compteur);
    return compteur;
}

//-------------------------------------------------------------------------------------
int supprime_pikomino_choisi(int x){
    Liste* L=NULL;
        L = insererEnFin(L,21);
        L = insererEnFin(L,22);
        L = insererEnFin(L,23);
        L = insererEnFin(L,24);
        L = insererEnFin(L,25);
        L = insererEnFin(L,26);
        L = insererEnFin(L,27);
        L = insererEnFin(L,28);
        L = insererEnFin(L,29);
        L = insererEnFin(L,30);
        L = insererEnFin(L,31);
        L = insererEnFin(L,32);
        L = insererEnFin(L,33);
        L = insererEnFin(L,34);
        L = insererEnFin(L,35);
        L = insererEnFin(L,36);


        L=supprimerUnElement(L,x);
        affichage(L);
}
//-----------------------------------------------------------------------------------------
//lance les dés au hasard et met les valeurs dans un tableau
int lancerdedes(int nb)
{

    int tableau[9];
    int i,j=0;

    srand(time(NULL));
    for(i=0;i<8;i++)
    {
        j=rand()%6;

        tableau[i]=j+1;
        printf(" [%d]  ",tableau[i]);

    }
    nombreOccurence(tableau,8,nb);
    return 0;
}
//--------------------------------------------------------------------------------------
//joueur1
void joueur1()
{
    int njoueur1;
    printf("\tbonne chance joueur 1 :) : \n");
    lancerdes1();
}

//---------------------------------------------------------------------------------------
//joueur2
void joueur2()
{
    int njoueur2;
    printf("\tbonne chance joueur 2 :) : \n");
    lancerdes2();
}

//--------------------------------------------------------------------------------------------------
//lancer de des du joueur 1 + choix pickomino + options pour la suite du jeu
int lancerdes1enleve(int x) //#############***********######*****
{
    static int sommedes1=0;
    int des;
    int tab[8];
    printf("Voici le resultat de votre lancer de des : \n\n");
    int tableau[9];
    int i,j=0;

    srand(time(NULL));
    for(i=0;i<x;i++)
    {
        j=rand()%6;

        tableau[i]=j+1;
        printf(" |%d|  ",tableau[i]);

    }
    printf("\n***Saisissez le numeros des des que vous souhaitez garder\n");
    scanf("%d",&des);
   // des_interdit(tab,des);
    int m=nombreOccurence(tableau,8,des);
    sommedes1=sommedes1+(m*des);
    //printf("x: %d\n",n);


    printf("La somme des des est : %d\n ",sommedes1 );

    x=x-m;
    if(x==0)
    {
        printf("Le tour est terminee!");
        system("PAUSE");
        return 0;
    }
    int numpiko;
    lancerdes1enleve(x); //#######********####
    if (sommedes1<21){
        printf("Vous n'avez pas assez de points :( \nTour rate :( \n");
        //lancerdes1enleve(x); //#######********####
        joueur2();
    }
    else{
        printf("\n\nVous avez assez de point pour choisir un pikomino!\n\n/Prenez-le vite ! : \nAttention !! Vous ne pouvez pas choisir le meme pickomino que le joueur 2 meme s'il est dans la liste\n");
        scanf("%d", &numpiko);
            if (numpiko> sommedes1 ){
                printf("\nVous n'avez pas assez de points, veuillez choisir un autre pikomino : ");
                scanf("%d", &numpiko);
                if(numpiko<21 || numpiko>36){
                    printf("\nVous devez donner un numero de pikomino entre 21 et 36 !\nVeuillez choisir un autre pikomino : ");
                    scanf("%d",&numpiko);
                }
            }
            else if(numpiko<21 || numpiko>36){
                printf("\nVous devez donner un numero de pikomino entre 21 et 36 !\nVeuillez choisir un autre pikomino : ");
                scanf("%d",&numpiko);

            }
             printf("\nVotre dernier pikomino selectionne est: [%d] \n\n\n",numpiko);
             FILE *fp;
            fp = fopen("file.txt","a");
            fprintf(fp,"\npickomino pris par joueur 1 = %d\n",numpiko);
            fclose(fp);

    }

    stockpickominojoueur1(&numpiko);
    printf("\n\n\npickominos selectionne par les 2 joueurs,\nvous ne pouvez plus les selectionner !\n");
    tab1ettab2(&numpiko);


        //void piko();
        printf("\n\t\tLaissez place au joueur 2 !\n\n");

        // pickominos restants au centre de la table
        milieuTable(&numpiko);


       // finjeu();

        sommedes1 = 0;

        int choix;
        printf("\n\nSi vous voulez arreter et voir les resultats de la partie en cours, tapez 0\nSi vous voulez continuer a jouer, tapez 1 :\n");
        scanf("%d",&choix);
        if(choix==0){
            finjeu();
            system("PAUSE");
            exit(0);
        }
        else if(choix==1){
            printf("\n----------------------------------------------------------------------------------------------------------------------------------------------------\n");
            joueur2();
        }
}

//-----------------------------------------------------------------------------------------------------------------------------------------


//lancer de des pour le joueur 1
void lancerdes1()
{
    int x=8;
    lancerdes1enleve(x);

}





//---------------------------------------------------------------------------------------------------------------------------------------------------------------------
//lancer de des du joueur 2 + choix pickomino + options pour la suite du jeu
int lancerdes2enleve(int x) //#############***********######*****
{
    static int sommedes2=0;
    int des;
    int tab[8];
    printf("Voici le resultat de votre lancer de des : \n\n");
    int tableau[9];
    int i,j=0;

    srand(time(NULL));
    for(i=0;i<x;i++)
    {
        j=rand()%6;

        tableau[i]=j+1;
        printf(" |%d|  ",tableau[i]);

    }
    printf("\n***Saisissez le numeros des des que vous souhaitez garder\n");
    scanf("%d",&des);
   // des_interdit(tab,des);
    int m=nombreOccurence(tableau,8,des);
    sommedes2=sommedes2+(m*des);
    //printf("x: %d\n",n);


    printf("La somme des des est : %d\n ",sommedes2 );

    x=x-m;
    if(x==0)
    {
        printf("Le tour est terminee!");
        system("PAUSE");
        return 0;
    }
    int numpiko;
    lancerdes2enleve(x); //#######********####
    if (sommedes2<21){
        printf("Vous n'avez pas assez de points :( \nTour rate :( \n");
        //lancerdes1enleve(x); //#######********####
        joueur1();
    }
    else{
        printf("\n\nVous avez assez de point pour choisir un pikomino!\n\n/Prenez-le vite  ! :\nAttention !! Vous ne pouvez pas choisir le meme pickomino que le joueur 1 meme s'il est dans la liste\n");
        scanf("%d", &numpiko);
            if (numpiko> sommedes2){
                printf("\nVous n'avez pas assez de points, veuillez choisir un autre pikomino : ");
                scanf("%d", &numpiko);
                if(numpiko<21 || numpiko>36){
                    printf("\nVous devez donner un numero de pikomino entre 21 et 36 !\nVeuillez choisir un autre pikomino : ");
                    scanf("%d",&numpiko);
                }
            }
            else if(numpiko<21 || numpiko>36){
                printf("\nVous devez donner un numero de pikomino entre 21 et 36 !\nVeuillez choisir un autre pikomino : ");
                scanf("%d",&numpiko);

            }
             printf("\nVotre dernier pikomino selectionne : [%d]\n\n\n",numpiko);
             FILE *fp;
            fp = fopen("file.txt","a");
            fprintf(fp,"\npickomino pris par joueur 2 = %d\n",numpiko);
            fclose(fp);

      // printf("pile joueur 2 \n");
       stockpickominojoueur2(&numpiko);
       printf("\n\npickominos selectionne par les 2 joueurs,\nvous ne pouvez plus les selectionner !\n");
       tab1ettab2(&numpiko);

        //void piko();
        printf("\n\t\tLaissez place au joueur 1 !\n\n");

        // pickominos restants au centre de la table
        milieuTable(&numpiko);

        sommedes2 = 0;

        int choix;
        printf("\n\n Si vous voulez arreter et voir les resultats de la partie en cours, tapez 0\nSi vous voulez continuer a jouer, tapez 1 :\n");
        scanf("%d",&choix);
        if(choix==0){
            finjeu();
            system("PAUSE");
            exit(0);
        }
        else if(choix==1){
            printf("\n----------------------------------------------------------------------------------------------------------------------------------------------------\n");
            joueur1();
        }

    }
}



//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//lancer de des pour le joueur 2
void lancerdes2()
{
    int x=8;
    lancerdes2enleve(x);
}
//-------------------------------------------------------------------------------------------------------------------------
//fonction pour demander au joueur 1 s'il souhaite relancer les des ou non
void rejouer1()
{
    int rejoue;
    printf("voulez vous rejouer ? \n/non : 0 , oui : 1 / ");
    scanf("%d",&rejoue);
    if (rejoue==1){
        lancerdes1enleve(8);
        printf("\n\n\n");
    }
    else if (rejoue==0) {
        printf("Au suivant !\n");
        joueur2();
        exit(3);
    }
}

//------------------------------------------------------------------------------------------------------------------------------------------------
//fonction pour demander au joueur 2 s'il souhaite relancer les d�s ou non
void rejouer2()
{
    int rejoue;
    printf("voulez vous rejouer ? \n/non : 0 , oui : 1 / ");
    scanf("%d",&rejoue);
    if (rejoue==1){
        lancerdes2();
        printf("\n\n\n");
    }
    else if (rejoue==0){
        printf("Au suivant !\n");
        joueur1();
        exit(3);
    }
}
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//lance le jeu et demande quel joueur joue en premier apres qu'ils aient determines qui faisaient le meilleur cris de dindon

void debutJeu()
{
    int numdonne;
        printf("\n\n\nFaites votre plus beau cris de dindon, et choisissez qui commence ! :D \n");

            while ((numdonne != 1) || (numdonne != 2))
            {
                printf(" Entrez votre numero de joueur : 1 ou 2 :  ");
                scanf("%d",&numdonne);
                if(numdonne==1){
                    printf("\n---------------------------------------------------------------------\n");
                    joueur1();
                }
                else if(numdonne==2){
                    printf("\n---------------------------------------------------------------------\n");
                    joueur2();
                }
            }
}


 //-----------------------------------------------------------------------------------------------------
 void finjeu(int stockpickominojoueur1,int stockpickominojoueur2)
 {
    // int j1=stockpickominojoueur1;
     //int j2=stockpickominojoueur2;
   //  printf("j1 = %d points \n",stockpickominojoueur1);
     //printf("j2 = %d points \n",stockpickominojoueur2);

    if (stockpickominojoueur1<stockpickominojoueur2)
    {
        printf("joueur 2 gagnant !\n");
    }
    else if(stockpickominojoueur1>stockpickominojoueur2)
    {
        printf("joueur 1 gagnant !\n");
    }

    int lecture;
    printf("Voulez-vous afficher le fichier de l'historique du jeu pour voire les scores finaux ? \n/oui:1 non:0 /");
    scanf("%d",&lecture);
    if(lecture == 1)
        lecturefichier();
    else if(lecture==0)
        system("PAUSE");

 }
//--------------------------------------------------------------------------------------------------------------

 int lecturefichier(void) {
    const char* filename = "file.txt";

    FILE* input_file = fopen(filename, "r");
    if (!input_file)
        exit(EXIT_FAILURE);

    struct stat sb;
    if (stat(filename, &sb) == -1) {
        perror("stat");
        exit(EXIT_FAILURE);
    }

    char* file_contents = malloc(sb.st_size);
    fread(file_contents, sb.st_size, 1, input_file);

    printf("%s\n", file_contents);

    fclose(input_file);
    free(file_contents);

    exit(EXIT_SUCCESS);
}


