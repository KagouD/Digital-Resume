#ifndef __PLAY__H__
#define __PLAY__H__
#include <time.h>



	/* Type bool�en */
	typedef enum
	{
		false, //0
		true //1
	}Bool;

	/*valeur V =5*/
	typedef enum
	{
	    V =5
	}ver;

	/*------------------------------------------*/

	struct pile
    {
        int tab[16];
        int top;
    };
    typedef struct pile PILE;
    PILE p;
	//-----------------------------------------------

	struct pile1
    {
        int tab[20];
        int top;
    };
    typedef struct pile1 PILE1;
    PILE1 p1;
    //-----------------------------------------------------
    struct pile2
    {
        int tab[20];
        int top;
    };
    typedef struct pile2 PILE2;
    PILE2 p2;
	//-------------------------------------------------------
	//definition d'une liste

	typedef struct Liste Liste;

	struct Liste
	{
	    int valeur;
	    Liste*suivant;
    };

//------------------------------------------------------------------------------
	/* D�finition d'une Pile */
	typedef struct ElementPile
	{
		int value;
		struct ElementPile *prochain;
	}ElementPile, *Pile;

	/*------------------------------------------*/

	/*prototypes fonctions pour les piles des joueurs */
        //joueur 1
	int stockpickominojoueur1(int *numpiko);
	void ajout_pikomino1(int item);
	int enlevedernierpiko1();
	void afficherpiletab1();

        //joueur 2
	int stockpickominojoueur2(int *numpiko);
	void ajout_pikomino2(int item);
	int enlevedernierpiko2();
	void afficherpiletab2();


	/*prototypes fonctions liste de pikomino*/

	void affichage(Liste* L);
	Liste* creerMaillon(int x);
	Liste* insererEnTete(Liste* L,int x);
	Liste* insererEnFin(Liste* head,int x);
	Liste* supprimerUnElement(Liste* head,int x);

	/*prototypes fonctions jeu*/
	//void supprime_pikomino(int t[20],int k);
	void piko();
	void joueur1();
	void joueur2();
	void lancerdes1();
	void lancerdes2();
	void rejouer1();
	void rejouer2();
	void debutJeu();
	int nombreOccurence(int tab[],int x ,int nbr);
	int lancerdedes();
	void finjeu();
//	int choix_piko();

#endif



